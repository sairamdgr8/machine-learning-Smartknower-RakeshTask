Problem Statment:
Description of the dataset is available at https://www.kaggle.com/tmdb/tmdb-movie-metadata

One needs to clean the data and perform EDA on it and answer any 4 of the following questions on the dataset.

One can clean (fix, replace, drop, etc) values with their respective choice. There is no restriction on it.

1) Which are the movies with the third-lowest and third-highest budget?
2) What is the average number of words in movie titles between the years 2000-2005?
3) What is the most common Genre for Vin Diesel & Emma Watson movies?
4) Which are the movies with the most and least earned revenue?
5) What is the average runtime of movies in the year 2006?

Prepare a word or preferably a PDF document with the questions and answers and zip it along with your ipynb notebook (or python script).

Note: The submission date of your minor project is 20th December.
               1. Please submit your project to event@smartknower.com
                2. If you have any technical queries, drop a mail to mentors@smartknower.com
                3. Projects will be evaluated if you submit your project to support@smartknower.com
                4. Proper subject line should be there while submitting your project, if not it will not be evaluated.
                5. Subject line format:  November-Minor Project-ML
